<?php
class Page{
    public function getPageList($page,$pageSize,$sqlA,$count){
       
        require_once('conn.php');
        $db = DB::getIntance();

        $s = ($page - 1) * $pageSize;
       
        $sql =$sqlA. " LIMIT {$s},{$pageSize}";
      
        $result = $db->getAll($sql);
       
        $data['table_count'] = $count;
        $data['pageSize'] = $pageSize;
        $data['data'] = [];
        foreach ($result as $key => $value) {
            $data['data'][] = $value;
        }
       
       
        return $data;
    } 
    public function getPage($data){
  
    $get = $_GET;
    $page = isset($get['page'])?$get['page']:1;


    $url = $_SERVER["REQUEST_URI"];
    $_par = parse_url($url);
  
    if (isset($_par['query'])) {
        parse_str($_par['query'],$_query);
        unset($_query['page']);
        $url = $_par['path'].'?'.http_build_query($_query)."&";
    }else{
        $url ="?";
    }
    $end_page = ceil($data['table_count'] / $data['pageSize']);
    $src = '';
    
    if($page == 1){
        $src = "<a><span>home page</span></a>&emsp;";
        $src .= "<a><span>prev page</span></a>&emsp;";
    }else{
        $src .= "<a href='{$url}page=1'>home page</a>&emsp;";
        $pages = $page - 1;
        $src .= "<a href='{$url}page={$pages}'>prev page</a>&emsp;";
    }

    if($page == $end_page){
        $src .= "<a ><span>next page</span></a>&emsp;";
        $src .= "<a><span>last page</span></a>&emsp;";
    }else{
        $pages = $page + 1;
        $src .= "<a href='{$url}page={$pages}'>next page</a>&emsp;";
        $src .= "<a href='{$url}page={$end_page}'>last page</a>&emsp;";
    }
    return $src;
}
}

?>