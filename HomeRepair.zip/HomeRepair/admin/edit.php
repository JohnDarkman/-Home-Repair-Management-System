<?php session_start();
if (!isset($_SESSION['admin_username']) || empty($_SESSION['admin_username'])) {
  echo '<script>
			alert("please sign in");
			location.href = "login.php";
		</script>';
}
?>
<!DOCTYPE html>
<html lang="zh-cn">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="renderer" content="webkit">
  <title></title>
  <link rel="stylesheet" href="css/pintuer.css">
  <link rel="stylesheet" href="css/admin.css">
  <script src="js/jquery.js"></script>
  <script src="js/pintuer.js"></script>
  <script src="js/ckeditor.js"></script>
  <style>
           
            .ck-editor__editable[role="textbox"] {
                /* editing area */
                min-height: 200px;
            }
            .ck-content .image {
                /* block images */
                max-width: 80%;
                margin: 20px auto;
            }
        </style>
</head>
<?php
require_once('../conn.php');
$db = DB::getIntance();
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $sql = 'select * from appointment where id='. $_GET['id'];
    $res = $db->getRow($sql);
}

?>

<body>
  <div class="panel admin-panel">
    <div class="panel-head" id="add"><strong><span class="icon-pencil-square-o"></span> 项目信息</strong></div>
    <div class="body-content">
      <form method="post" class="form-x" action="editOk.php" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $res['id']?>">
       
 
             <div class="form-group">
          <div class="label">
            <label>Status：</label>
          </div>
          <div class="field">
            <select name="status" class="input w50">
                <option value="To be processed" <?php if($res['status']== 'To be processed'){ echo "selected";} ?>>To be processed</option>
                <option value="In process" <?php if($res['status']== 'In process'){ echo "selected";} ?>>In process</option>
                <option value="Completed" <?php if($res['status']== 'Completed'){ echo "selected";} ?>>Completed</option>
                <option value="Cancelled" <?php if($res['status']== 'Cancelled'){ echo "selected";} ?>>Cancelled</option>
               
            </select>
            <div class="tips"></div>
          </div>
        </div>

        <div class="form-group">
          <div class="label">
            <label></label>
          </div>
          <div class="field">
            <button class="button bg-main icon-check-square-o" type="submit"> 提交</button>
          </div>
        </div>
      </form>
    </div>
  </div>

</body>

</html>