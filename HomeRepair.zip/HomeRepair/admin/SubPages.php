<?php
class Page{
    public function getPageList($page,$pageSize){
       
        require_once('../conn.php');
        $db = DB::getIntance();
      
        
        // $conn = mysqli_connect('127.0.0.1', 'root', 'root', 'page');
        $s = ($page - 1) * $pageSize;
        $sql = "SELECT * FROM appointment LIMIT {$s},{$pageSize}";
        $sql1 = "SELECT * FROM appointment";
        $result = $db->getAll($sql);
         $result1 = $db->getAll($sql1);
        $data['table_count'] = count($result1);
        $data['pageSize'] = $pageSize;
        $data['data'] = [];
        foreach ($result as $key => $value) {
            $data['data'][] = $value;
        }
        // if ($result->num_rows > 0) {
        //     while($row = $result->fetch_assoc()) {
        //         $data['data'][] = $row;
        //     }
        // }
       
        return $data;
    } 
    public function getPage($data){
   
    $get = $_GET;
    $page = isset($get['page'])?$get['page']:1;

   
    unset($get['page']);
    $url = http_build_query($get);
    $url = $url?$url.'&':'?';

    $end_page = ceil($data['table_count'] / $data['pageSize']);
    $src = '';
   
    if($page == 1){
        $src = "<a><span>home page</span></a>&emsp;";
        $src .= "<a><span>prev page</span></a>&emsp;";
    }else{
        $src .= "<a href='{$url}page=1'>home page</a>&emsp;";
        $pages = $page - 1;
        $src .= "<a href='{$url}page={$pages}'>prev page</a>&emsp;";
    }

    if($page == $end_page){
        $src .= "<a ><span>next page</span></a>&emsp;";
        $src .= "<a><span>last page</span></a>&emsp;";
    }else{
        $pages = $page + 1;
        $src .= "<a href='{$url}page={$pages}'>next page</a>&emsp;";
        $src .= "<a href='{$url}page={$end_page}'>last page</a>&emsp;";
    }
    return $src;
}
}

?>