<?php session_start();
if (!isset($_SESSION['admin_username']) || empty($_SESSION['admin_username'])) {
  echo '<script>
			alert("please sign in");
			location.href = "login.php";
		</script>';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="renderer" content="webkit">
  <title></title>
  <link rel="stylesheet" href="css/pintuer.css">
  <link rel="stylesheet" href="css/admin.css">
  <script src="js/jquery.js"></script>
  <script src="js/pintuer.js"></script>
</head>
<?php

require_once('SubPages.php');
$pageObj = new Page();
$page = isset($_GET['page'])?$_GET['page']:1;
$list =$pageObj->getPageList($page,15);

$page =$pageObj->getPage($list);


?>

<body>
  <form method="post" action="" id="listform">
    <div class="panel admin-panel">
      <div class="panel-head"><strong class="icon-reorder"> List</strong> </div>
     
      <table class="table table-hover text-center">
        <tr>
          <th>id</th>
          <th>name</th>
          <th>phone</th>
          <th>address</th>
          <th>appointment_time</th>
          <th>remark</th>
          <th>status</th>
         
             <th>Option</th>
          <!--<th>picture</th>-->
        </tr>
        <?php foreach($list['data']  as $value){  ?>
          <tr>
                <td><?php echo $value['id'] ?></td>
            <td><?php echo $value['name'] ?></td>
            <td><?php echo $value['phone'] ?></td>
            <td><?php echo $value['address'] ?></td>
            <td><?php echo $value['appointment_time'] ?></td>
             <td><?php echo $value['remark'] ?></td>
            <td><?php echo $value['status'] ?></td>
            <td>
                <?php 
                    if($value['status'] == 'To be processed' || $value['status'] == 'In process'){
                ?>
              <div class="button-group"> <a  href="edit.php?id=<?php echo $value['id'] ?>"><span ></span> Edit</a> </div>
              <?php } ?>
            </td>
          </tr>
        <?php } ?>
      </table>
      <div style="text-align:center;margin-top:20px;margin-bottom:20px;"><?php echo $page; ?></div>
    </div>
  </form>
  <script type="text/javascript">
    function changesearch() {
      var hotelName = $("#keywords").val();
      var sort = $("#sort").val();
      
        location.href = 'list.php?hotelName='+hotelName+'&sort='+sort;
    }
    function sorta() {
       var hotelName = $("#keywords").val();
      var sort = $("#sort").val();
      
        location.href = 'list.php?hotelName='+hotelName+'&sort='+sort;
    }

    function del(id) {
      if (confirm("确定删除?")) {
        var id = id;
        $.ajax({
          type: "post",
          url: "../function.php",
          data: {
            "function": "deleteProject",
            "id": id
          },
          dataType: "json",
          success: function(data) {
            if (data == 1) {
              location.href = 'list.php'
            }
          }
        });
      }
    }
  </script>
</body>

</html>