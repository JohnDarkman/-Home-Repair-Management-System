<?php
require_once('../conn.php');
$db = DB::getIntance();

$status = $_POST["status"];


if (isset($_POST['id']) && !empty($_POST['id'])) {
    
        $sql = "update appointment set 
        status= '".$status."'
        where id=  " . $_POST["id"];
   
    $res = $db->query($sql);
    if ($res > 0) {
        echo "<script>location.href='list.php';</script>";
    } else {
        echo "<script>alert('Fail to edit!');location.href='list.php';</script>";
    }
}
