<!DOCTYPE html>
<html lang="en-gb">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title>Login</title>  
    <link rel="stylesheet" href="css/pintuer.css">
    <link rel="stylesheet" href="css/admin.css">
    <script src="js/jquery.js"></script>
    <!--<script src="js/pintuer.js"></script>  -->
</head>
<body>
<div class="wallpaper"></div>
    <style>
		body {
			background-image: url('images/wallpaper.jpg');
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center center;
		}
	</style>
<div class="container">
    <div class="line bouncein">
        <div class="xs6 xm4 xs3-move xm4-move">
            <div style="height:150px;"></div>
            <div class="media media-y margin-big-bottom">           
            </div>         
            <div class="panel loginbox">
                <div class="text-center margin-big padding-big-top"><h1>Appointment Management</h1></div>
                <div class="panel-body" style="padding:30px; padding-bottom:10px; padding-top:10px;">
                    <div class="form-group">
                        <div class="field field-icon-right">
                            <input type="text" class="input input-big" id="username" name="username"  placeholder="Enter username" required/>
                            <span class="icon icon-user margin-small"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="field field-icon-right">
                            <input type="password" class="input input-big" name="password" id="password" placeholder="Enter password" required  />
                            <span class="icon icon-key margin-small"></span>
                            <p style="margin-top:10px;color:red" id = "error"></p>
                        </div>
                    </div>
                </div>
                <div style="padding:20px;"><input type="submit" id="login" class="button button-block bg-main text-big input-big" value="Login"></div>
            </div>
        </div>
    </div>
</div>

</body>
<script type="text/javascript">
		$("#login").click(function() {
			var username = $("#username").val();
			var password = $("#password").val();
			$.ajax({
				type: "post",
				url: "../function.php",
				data:{"function":"adminLogin","username":username,"password":password},
				dataType: "json",
				success: function(data) {
					if (data == 1) {
						location.href = 'index.php'
					} else {
						message = "The password is incorrect";
						$("#error").html(message)
					}
				}
			});
		});
	</script>
</html>