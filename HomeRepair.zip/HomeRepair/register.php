<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Home Repair Appointment System</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/public.css">
	<script src="js/html5shiv.js" type="text/javascript"></script>
	<script src="js/respond.min.js" type="text/javascript"></script>
</head>

<body>
<div class="wallpapercs"></div>
	<style>
		body {
			background-image: url('images/wallpapercs.jpg');
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center center;
		}
	</style>
</body>
	<div class="show-register">
		<h1 style="text-align:center;padding-top: 10px;">Old Home's Club</h1>
		<h1 style="text-align:center;padding-top: 10px;">Sign up</h1>
		<form action="doRegister.php" method="POST" enctype="multipart/form-data">
			<div style="margin-left: 10px;margin-right: 10px;">
				<p>Username:</p>
				<input name="username" id="username" class="form-control" type="text" oninput="checkUsername()" required="required" placeholder="please enter user name">
				<p style="margin-top:10px;color:red" id = "exist"></p>
			
				<p style="margin-top:10px">Password:</p>
				<input name="password" class="form-control" type="password" required="required" placeholder="please enter password">

			</div>
			<button type="submit" id="submit"  style="margin-left: 40%;margin-top: 15px;margin-bottom: 15px;text-align:center;background-color: #212529;border-color: #212529;color: #fff;" class="btn btn-default">Register</button>
		</form>
	</div>
	<div>
		<p style="margin-left: 45%;margin-top: 10px;">Already have an account? <a class="underline" href="login.php">to log in</a>
	</div>
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
	function checkUsername()
 {
 	var username = $("#username").val();
 
    $.ajax
    ({
    	url: "check.php",
		dataType: "json",
		type: "post",
		data: { 
			    username: username
			  },
	    success:function(res){
		      if(res == 1){
		          $("#exist").html("Username already exists");
		          $("#submit").attr("disabled","disabled");
		      }else{
		           $("#exist").html("");
		           $("#submit").removeAttr("disabled");
		      }
		}
    });
 }
</script>
</body>

</html>