<?php
require_once('conn.php');
$db = DB::getIntance();

$username = $_POST['username'];

$sql = 'select * from user where username="'.$username.'"';

$res = $db->getRow($sql);
if(!empty($res)){
    echo 1;
}else{
    echo 2;
}
