<?php session_start();
unset($_SESSION['username']) ;
unset($_SESSION['user_id']);
echo "<script>alert('logout successful!');location.href='login.php';</script>";
?>
