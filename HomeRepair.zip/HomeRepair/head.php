<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <nav style="background-color: #212529;" class="navbar navbar-default navbar-fixed-top navbar-inverse" role="navigation">
        <div class="">
            <div class="navbar-header">
                <a class="navbar-brand" href="appointment.php">Home</a>
                 <a class="navbar-brand" href="list.php">My Appointment</a>
            </div>
            <div class="collapse navbar-collapse" id="demo-navbar" style="float: right;">
                <ul class="nav navbar-nav">
                    <?php
                    if (isset($_SESSION['username']) && !empty($_SESSION['username'])) {
                        echo '<li><a href="logout.php">Logout</a></li>';
                    } else {
                        echo '<li><a href="login.php">Login</a></li>
						<li><a href="register.php">Register</a></li>';
                    }
                    ?>

                </ul>
               
            </div>
        </div>
    </nav>
</body>

</html>