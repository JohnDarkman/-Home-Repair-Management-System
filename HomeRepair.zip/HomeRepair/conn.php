<?php
class DB
{
  private static $dbcon = false;
  private $host;
  private $port;
  private $user;
  private $pass;
  private $db;
  private $charset;
  private $link;
  private function __construct()
  {
    $this->host = 'localhost';
    $this->port = '3306';
    $this->user = 'root';
    $this->pass = '';
    $this->db = 'aapp009_wzjk';
    $this->charset = 'utf8';
    $this->db_connect();
    $this->db_usedb();
    $this->db_charset();
  }
  private function db_connect()
  {
    $this->link = mysqli_connect($this->host . ':' . $this->port, $this->user, $this->pass);
    if (!$this->link) {
      echo "database connect error<br>";
      echo "error code" . mysqli_errno($this->link) . "<br>";
      echo "error msg" . mysqli_error($this->link) . "<br>";
      exit;
    }
  }
  private function db_charset()
  {
    mysqli_query($this->link, "set names {$this->charset}");
  }
  private function db_usedb()
  {
    mysqli_query($this->link, "use {$this->db}");
  }
  private function __clone()
  {
    die('clone is not allowed');
  }
  public static function getIntance()
  {
    if (self::$dbcon == false) {
      self::$dbcon = new self;
    }
    return self::$dbcon;
  }
  public function query($sql)
  {
    $res = mysqli_query($this->link, $sql);
    if (!$res) {
      echo "exec sql error<br>";
      echo "error code" . mysqli_errno($this->link) . "<br>";
      echo "error msg" . mysqli_error($this->link) . "<br>";
    }
    return $res;
  }
 
  public function getRow($sql, $type = "assoc")
  {
    $query = $this->query($sql);
    if (!in_array($type, array("assoc", 'array', "row"))) {
      die("mysqli_query error");
    }
    $funcname = "mysqli_fetch_" . $type;
    return $funcname($query);
  }
 
  public function getAll($sql)
  {
    $query = $this->query($sql);
    $list = array();
    while ($r = $this->getFormSource($query)) {
      $list[] = $r;
    }
    return $list;
  }
  public function getFormSource($query,$type="assoc"){
      if(!in_array($type,array("assoc","array","row")))
      {
       die("mysqli_query error");
      }
      $funcname="mysqli_fetch_".$type;
      return $funcname($query);
  }
 
}
