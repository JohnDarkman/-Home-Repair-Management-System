<?php
require_once('conn.php');
$db = DB::getIntance();
$username = $_POST["username"];
$sql = 'select * from user where username="'.$username.'"';
$res = $db->getRow($sql);
if(!empty($res)){
     echo "<script>alert('Username already exists!');;location.href='register.php';</script>";
}else{

    $password = $_POST["password"];
    
    $sql = "insert into user (username,password) 
    values ('" . $username . "','" . $password . "')";
    $res = $db->query($sql);
    if ($res > 0) {
        echo "<script>alert('registration success!');location.href='login.php';</script>";
    } else {
        echo "<script>alert('registration failed!');location.href='register.php';</script>";
    }
    
}





