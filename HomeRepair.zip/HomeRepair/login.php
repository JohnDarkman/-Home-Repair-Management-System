<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Home Repair Appointment System</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/public.css">
	<script src="js/html5shiv.js" type="text/javascript"></script>
	<script src="js/respond.min.js" type="text/javascript"></script>
</head>

<body>
<div class="wallpaper"></div>
    <style>
		body {
			background-image: url('images/wallpaper.jpg');
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center center;
		}
	</style>


	<div class="show-login">
		<h1 style="text-align:center;padding-top: 10px;">Old Home's Club</h1>
		<h1 style="text-align:center;padding-top: 10px;">Sign in</h1>
		<form action="doLogin.php" method="POST">
			<div style="margin-left: 10px;margin-right: 10px;">
				<p>Username:</p>
				<input class="form-control" type="text" id="username" name="username" required="required" placeholder="please enter user name">
				<p style="margin-top:10px">Password:</p>
				<input class="form-control" type="password" id="password" name="password" required="required" placeholder="please enter password">
			</div>
		
			<button type="submit" style="margin-top: 15px;" class="btn btn-default login">Login</button>
		</form>
	</div>
	<div>
		<p style="margin-left: 45%;margin-top: 10px;">No account? <a class="underline" href="register.php">to register</a>
	</div>
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

</body>

</html>