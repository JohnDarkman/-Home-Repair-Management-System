
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Home Repair Appointment System</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/public.css">
	<script src="js/html5shiv.js" type="text/javascript"></script>
	<script src="js/respond.min.js" type="text/javascript"></script>
</head>
<body>
	<?php
	require_once('head.php');
	require_once('conn.php');
	require_once('pages.php');
	$db = DB::getIntance();
	$user_id = $_SESSION['user_id'];

	
    $pageObj = new Page();
    $page = isset($_GET['page'])?$_GET['page']:1;
    $sql = 'select * from appointment where user_id = ' . $user_id;
    $all = $db->getAll($sql);
    $list =$pageObj->getPageList($page,20,$sql,count($all));
    $page =$pageObj->getPage($list);
	
	?>

	<div>
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th style="text-align: center;">id</th>
					<th style="text-align: center">name</th>
					<th style="text-align: center">phone</th>
					<th style="text-align: center">address</th>
					<th style="text-align: center">appointment_time</th>
					<th style="text-align: center">status</th>
					<th style="text-align: center">remark</th>
					<th style="text-align: center">Option</th>
					
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($list['data'] as $key => $value) {
					$strEdit = '';
					if($value['status'] == 'To be processed'){
					    $strEdit = 'Cancel';
					}
					echo '<tr>
				<td style="text-align: center">' . $value['id'] . '</td>
				<td style="text-align: center">' . $value['name'] . '</td>
				<td style="text-align: center">' . $value['phone'] . '</td>
				<td style="text-align: center">' . $value['address'] . '</td>
				<td style="text-align: center">' . $value['appointment_time'] . '</td>
				<td style="text-align: center">' . $value['status'] . '</td>
				<td style="text-align: center">' . $value['remark'] . '</td>
				<td style="text-align: center"><a class="underline" href="javascript:void(0)" onclick = "cancle('.$value['id'].')">' . $strEdit . '</a></td>
				</td>
			</tr>';
				}

				?>
			</tbody>
		</table>
	
			 <div style="text-align:center;margin-top:20px;margin-bottom:20px;"><?php echo $page; ?></div>
	</div>
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
		function cancle(id){
		    if(confirm("Are you sure you want to cancel this appointment?")){
			var id = id;
    			$.ajax({
    				type: "post",
    				url: "function.php",
    				data:{"function":"userCancel","id":id},
    				dataType: "json",
    				success: function(data) {
    					if(data == 1){
    					    alert('You have canceled your appointment');
    					    location.reload();
    					}
    				}
    			});
            }
		}
	</script>
</body>

</html>