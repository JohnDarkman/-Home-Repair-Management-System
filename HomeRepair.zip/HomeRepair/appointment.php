<?php session_start();
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
	echo '<script>
			alert("请登录");
			location.href = "login.php";
		</script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Home Repair Appointment System</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/public.css">
</head>
<body>
    <a class="navbar-brand" href="list.php">Appointment</a>
	<div class="wallpaper"></div>
    <style>
		body {
			background-image: url('images/wallpaper.jpg');
			background-size: cover;
			background-repeat: no-repeat;
			background-position: center center;
		}
    </style>

	<div class="show-register">
		<h1 style="text-align:center;padding-top: 10px;">Online Home Repair Appointment System</h1>
		<form action="doAdd.php" method="POST">
			<div style="margin-left: 10px;margin-right: 10px;">
				<p>name:</p>
				<input name="name" class="form-control" type="text" required="required" placeholder="name">
				<p style="margin-top:10px">phone:</p>
				<input name="phone" class="form-control" type="text" required="required" placeholder="phone">
				<p style="margin-top:10px">address:</p>
				<input name="address" class="form-control" type="text" required="required" placeholder="address">
				<p style="margin-top:10px">appointment time:</p>
				<input name="appointment_time" class="form-control" type="text" required="required" placeholder="appointment time">
				<p style="margin-top:10px">remark:</p>
				<textarea class="form-control" rows="3" name = "remark"></textarea>
			</div>
			<div style="text-align:center">
			    <button type="submit" style="margin-top: 15px;background-color: #212529;border-color: #212529;color: #fff;" class="btn btn-default">Submit</button>
			</div>
            <h2 style="text-align:center;padding-top: 10px;">By:Old Home's Club</h2>
		</form>
	</div>
</body>
	
</html>