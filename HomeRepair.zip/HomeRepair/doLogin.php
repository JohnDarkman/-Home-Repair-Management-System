<?php
session_start();
require_once('conn.php');
$db = DB::getIntance();

$username = $_POST['username'];
$password = $_POST['password'];

$sql = 'select * from user where username="'.$username.'"';

$res = $db->getRow($sql);
if(!empty($res)){
    if($res['password'] != $password){
        echo "<script>alert('wrong password!');location.href='login.php';</script>";
    }else{
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $res['id'];
        echo "<script>location.href='appointment.php';</script>";
    }
}else{
    echo "<script>alert('The user does not exist, please register!');location.href='login.php';</script>";
}
