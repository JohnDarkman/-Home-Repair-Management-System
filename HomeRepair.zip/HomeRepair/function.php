<?php
session_start();
require_once('conn.php');
$function = $_POST['function'];

switch ($function) {
   
    case 'adminLogin':
        adminLogin();
        break;
   case 'adminLogout':
        adminLogout();
        break;
    case 'deleteProject':
        deleteProject();
        break;
    case 'userCancel':
        userCancel();
        break;
    default:
        # code...
        break;
}




function adminLogin()
{
    $db = DB::getIntance();
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);
    $sql = 'select * from admin where username= "'.$username.'"';
    $res = $db->getRow($sql);
    if ($res && $res['password'] == $password) {
        $_SESSION['admin_username'] = $res['username'];
        $_SESSION['admin_userId'] = $res['id'];
        echo 1;
    } else {
        echo 2;
    }
}

function adminLogout()
{
    unset($_SESSION['admin_username']);
    unset($_SESSION['admin_userId']);
    echo 1;
}

function deleteProject()
{
   
}
function userCancel()
{
    $db = DB::getIntance();
    $id = $_POST['id'];
    $sql = 'update appointment set status="Cancelled" where id='.$id;
	$db->query($sql);
    echo 1;
}



