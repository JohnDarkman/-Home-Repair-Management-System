<?php
session_start();
require_once('conn.php');
$db = DB::getIntance();
$user_id = $_SESSION['user_id'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$appointment_time = $_POST['appointment_time'];
$remark = $_POST['remark'];
$status = 'To be processed';

$sql = "insert into `appointment` (`name`, `phone`,`address`,`appointment_time`, `remark`,`user_id`,`status`) 
VALUES ('{$name}', '{$phone}','{$address}','{$appointment_time}', '{$remark}','{$user_id}','{$status}')";
$res = $db->query($sql);
if ($res > 0) {
    echo "<script>alert('Appointment successful!');location.href='list.php'</script>";
}else{
    echo "<script>alert('Appointmen failed!');location.href='appointment.php'</script>";
}
